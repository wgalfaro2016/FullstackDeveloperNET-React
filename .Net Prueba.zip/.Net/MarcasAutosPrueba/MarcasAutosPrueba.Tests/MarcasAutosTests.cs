using MarcasAutosPrueba.API;
using MarcasAutosPrueba.Application.Interfaces;
using MarcasAutosPrueba.Application.Services;
using MarcasAutosPrueba.Domain;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace MarcasAutosPrueba.Tests;

public class MarcasAutosTests
{
    private readonly Mock<IMarcaAutoService> _serviceMock;
    private readonly MarcasAutosController _controller;
    private readonly MarcaAutoService _service;
    private readonly Mock<IMarcaAutoRepository> _repoMock;


    public MarcasAutosTests() {
        _serviceMock = new Mock<IMarcaAutoService>();
        _controller = new MarcasAutosController(_serviceMock.Object);
        _repoMock = new Mock<IMarcaAutoRepository>();
        _service = new MarcaAutoService(_repoMock.Object);
    }

    [Fact]
    public async Task GetAll_ShouldReturnBrands() {
        var expected = new List<MarcaAutos>
        {
            new MarcaAutos { Id = 1, NombreMarca = "Mazda" }
        };

        _repoMock.Setup(r => r.GetAll()).ReturnsAsync(expected);

        var result = await _service.GetAll();

        Assert.Single(result);
        Assert.Equal("Mazda", result[0].NombreMarca);
    }

    [Fact]
    public async Task Get_ShouldReturnOk_WithListOfMarcas() {
   
        var expectedList = GetFakeBrands();
        _serviceMock.Setup(s => s.GetAll()).ReturnsAsync(expectedList);

      
        var result = await _controller.Get();

        var okResult = Assert.IsType<OkObjectResult>(result);
        var actualList = Assert.IsAssignableFrom<List<MarcaAutos>>(okResult.Value);
        Assert.Equal(expectedList.Count, actualList.Count);
    }

    [Theory]
    [InlineData(3)]
    [InlineData(5)]
    public async Task Get_ShouldReturn_CorrectNumberOfItems(int count) {
        
        var testData = GetFakeBrands().Take(count).ToList();
        _serviceMock.Setup(s => s.GetAll()).ReturnsAsync(testData);

      
        var result = await _controller.Get();

       
        var okResult = Assert.IsType<OkObjectResult>(result);
        var marcas = Assert.IsType<List<MarcaAutos>>(okResult.Value);
        Assert.Equal(count, marcas.Count);
    }

    [Fact]
    public async Task Get_ShouldReturnCorrectData() {
        
        var expected = GetFakeBrands();
        _serviceMock.Setup(s => s.GetAll()).ReturnsAsync(expected);

      
        var result = await _controller.Get();

       
        var okResult = Assert.IsType<OkObjectResult>(result);
        var marcas = Assert.IsAssignableFrom<List<MarcaAutos>>(okResult.Value);

        Assert.Equal("Mazda", marcas[0].NombreMarca);
        Assert.Equal("Ford", marcas[1].NombreMarca);
    }

    [Fact]
    public async Task Get_ShouldReturnEmptyList_WhenNoBrandsExist() {
        _serviceMock.Setup(s => s.GetAll()).ReturnsAsync(new List<MarcaAutos>());

        var result = await _controller.Get();

        var okResult = Assert.IsType<OkObjectResult>(result);
        var list = Assert.IsType<List<MarcaAutos>>(okResult.Value);

        Assert.Empty(list);
    }

    private List<MarcaAutos> GetFakeBrands() {
        return new List<MarcaAutos>
        {
                new MarcaAutos { Id = 1, NombreMarca = "Mazda" },
                new MarcaAutos { Id = 2, NombreMarca = "Ford" },
                new MarcaAutos { Id = 3, NombreMarca = "BMW" },
                new MarcaAutos { Id = 4, NombreMarca = "Ferrari" },
                new MarcaAutos { Id = 5, NombreMarca = "Chevrolet" }
            };
    }
}