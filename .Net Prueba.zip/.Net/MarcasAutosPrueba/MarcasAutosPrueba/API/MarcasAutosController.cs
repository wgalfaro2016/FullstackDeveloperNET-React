﻿using MarcasAutosPrueba.Application.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MarcasAutosPrueba.API
{
    [Route("api/[controller]")]
    [ApiController]

   
    public class MarcasAutosController : ControllerBase
    {
        private readonly IMarcaAutoService _service;

        public MarcasAutosController(IMarcaAutoService service) {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get() {
            var brands = await _service.GetAll();
            return Ok(brands);
        }
    }
}
