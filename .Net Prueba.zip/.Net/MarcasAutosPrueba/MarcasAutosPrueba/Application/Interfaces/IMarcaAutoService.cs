﻿using MarcasAutosPrueba.Domain;

namespace MarcasAutosPrueba.Application.Interfaces
{
    public interface IMarcaAutoService
    {
        Task<List<MarcaAutos>> GetAll();
    }
}
