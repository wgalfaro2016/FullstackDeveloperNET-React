﻿using MarcasAutosPrueba.Domain;

namespace MarcasAutosPrueba.Application.Interfaces
{
    public interface IMarcaAutoRepository
    {
        Task<List<MarcaAutos>> GetAll();
    }
}
