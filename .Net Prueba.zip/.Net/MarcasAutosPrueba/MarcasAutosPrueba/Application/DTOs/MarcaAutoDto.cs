﻿namespace MarcasAutosPrueba.Application.DTOs
{
    public class MarcaAutoDto
    {
    }
}
