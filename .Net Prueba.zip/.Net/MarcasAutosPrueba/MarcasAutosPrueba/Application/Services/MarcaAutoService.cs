﻿using MarcasAutosPrueba.Application.Interfaces;
using MarcasAutosPrueba.Domain;

namespace MarcasAutosPrueba.Application.Services
{
    public class MarcaAutoService : IMarcaAutoService
    {
        private readonly IMarcaAutoRepository _repository;

        public MarcaAutoService(IMarcaAutoRepository repository) {
            _repository = repository;
        }
        public async Task<List<MarcaAutos>> GetAll() {
            return await _repository.GetAll();
        }
    }
}
