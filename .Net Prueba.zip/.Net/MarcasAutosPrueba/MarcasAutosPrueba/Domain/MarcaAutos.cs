﻿namespace MarcasAutosPrueba.Domain
{
    public class MarcaAutos
    {
            public int Id { get; set; }
            public string NombreMarca { get; set; }
    }
}
