﻿using MarcasAutosPrueba.Application.Interfaces;
using MarcasAutosPrueba.Domain;
using Microsoft.EntityFrameworkCore;

namespace MarcasAutosPrueba.Infrastructure.Repositories
{
    public class MarcaAutoRepository : IMarcaAutoRepository
    {
        private readonly AppDbContext _context;

        public MarcaAutoRepository(AppDbContext context) {
            _context = context;
        }

        public async Task<List<MarcaAutos>> GetAll() {
            return await _context.MarcasAutos.ToListAsync();
        }
    }
}
