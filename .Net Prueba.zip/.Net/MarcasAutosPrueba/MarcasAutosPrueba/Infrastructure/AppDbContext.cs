﻿using MarcasAutosPrueba.Domain;
using Microsoft.EntityFrameworkCore;

namespace MarcasAutosPrueba.Infrastructure
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options) { }
        public DbSet<MarcaAutos> MarcasAutos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<MarcaAutos>().HasData(
                new MarcaAutos { Id = 1, NombreMarca = "Mazda" },
                new MarcaAutos { Id = 2, NombreMarca = "Ford" },
                new MarcaAutos { Id = 3, NombreMarca = "BMW" },
                new MarcaAutos { Id = 4, NombreMarca = "Ferrari" },
                new MarcaAutos { Id = 5, NombreMarca = "Chevrolet" }
            );
        }
    }
}
